// Handle user registration
app.post('/register', (req, res) => {
